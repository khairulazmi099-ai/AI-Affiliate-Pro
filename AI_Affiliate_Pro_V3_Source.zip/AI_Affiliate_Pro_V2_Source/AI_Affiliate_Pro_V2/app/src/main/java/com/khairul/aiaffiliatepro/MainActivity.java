package com.khairul.aiaffiliatepro;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebSettings; import android.webkit.WebView;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); w.setBackgroundColor(0xFF100B0B); setContentView(w); w.loadUrl("file:///android_asset/index.html");}
}
