AI AFFILIATE PRO 2.0 - Android Studio project

This ZIP is source code, not a compiled APK. The current build environment has no Android SDK/Gradle installed, so an installable APK could not be compiled or tested here.

Build:
1. Install Android Studio on a computer.
2. Extract this ZIP and open the folder in Android Studio.
3. Allow Gradle sync and SDK downloads.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK output: app/build/outputs/apk/debug/app-debug.apk

Features:
- TikTok, Threads, Facebook content.
- 10 marketing styles and multiple hook count selection.
- Local template generation with no API fee.
- Optional AI via configurable OpenAI-compatible Chat Completions endpoint and user-provided API key.
- Local script history and copy actions.

Important:
- API calls may incur provider charges. ChatGPT Free/Plus subscriptions do not include API credits.
- API key is stored in local WebView storage on the device; this is intended for personal testing, not public distribution.
- Shopee/TikTok product pages are not scraped automatically. Paste the URL as reference and enter product facts manually. Automatic extraction is not included because those sites may block automated access and expose dynamic/affiliate redirect content.
- Test the app and verify all product claims, prices, stock, discounts and specs before posting.
